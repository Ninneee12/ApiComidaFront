import React from 'react';

import Login from './pages/LoginPage/Login';
import Esquecisenha from './pages/LoginPage/Esquecisenha';




function App() {
  return (
    <Login/>
  //  <Esquecisenha/> 

  );
}

export default App
