import React, { useEffect, useRef, useState } from "react";


const Login = () => {
  const emailRef = useRef();   /* campo cursor email */
  const [email, setEmail] = useState(""); /* variável email hook */
  const [password, setPassword] = useState("") /* variável senha hook */
  const [validEmail, setValidEmail] = useState(false)
  const [validPassword, setValidPassword] = useState(false)
  const EMAIL_REGEX = /[^@ \t\r\n]+@[^@ \t\r\n]+\.[^@ \t\r\n]+/;
  const PWD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%]).{8,24}$/;


  useEffect(() => {
    emailRef.current.focus() /* mantém foco no campo que estou digitando */
  }, []) /* colchetes vazio precisa para executar uma unica vez */

  useEffect(() => {
    setValidEmail(EMAIL_REGEX.test(email))   /*valida email */
  }, [email])

  useEffect(() => {
    setValidPassword(PWD_REGEX.test(password))  /* valida senha com a expressao regular*/
  }, [password])

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("submit", { email, password });
  };
  return (
    <div className="h-screen flex items-center justify-center">
      <form onSubmit={handleSubmit} className="w-full md:w-1/3 bg-white rounded-lg item center">
        <div className="flex font-bold justify-center mt-6">
        </div>
        <h2 className="text-3x1 text-center text-gray-700 mb-4"> Seja Bem vindo </h2>
        <div className="px-12 pb-10">
          <div className="w-full mb-2">
            <div className="flex justify-center">
              <input type="email" placeholder="Email" required id="email" role="input" name="email"
                ref={emailRef}
                autoComplete="off"
                onChange={(e) => setEmail(e.target.value)}
                className="px-8 w-full border rounded py-2 text-gray-700 focus:outline-none items-center" />
            </div>
            <div className="w-full mb-2">
              {validEmail || !email ? null : <div className="text-red-500 text-xs italic">Email inválido.</div>}
            </div>
          </div>

          <div className="w-full mb-2">
            <div className="flex justify-center">
              <input type="password" placeholder="Password" required id="password" role="input" name="password"
                onChange={(e) => setPassword(e.target.value)}
                className="px-8 w-full border rounded py-2 text-gray-700 focus:outline-none items-center" />
            </div>
            <div className="w-full mb-2">
              {validPassword || !password ? null : <div className="text-red-500 text-xs italic">Senha inválida.</div>}
            </div>
          </div>
          <a href="#!" class="text-blue-600 hover:text-blue-700 focus:text-blue-700 transition duration-200 ease-in-out">Esqueceu
              senha?</a>
          <button disabled={!validEmail || !validPassword} role="button"
            className={(validEmail && validPassword) ? "w-full mt-6 py-2 rounded bg-blue-700 text-gray-100 focus:outline-none" : "w-full mt-6 py-2 rounded bg-blue-500 text-gray-100 focus:outline-none"}>Log In</button>
         
          <p class="text-gray-800 mt-6 text-center">Not a member? <a href="#!"class="text-blue-600 hover:text-blue-700 focus:text-blue-700 transition duration-200 ease-in-out">Register</a></p>
        </div>
      </form>
    </div>
  )

};

export default Login;