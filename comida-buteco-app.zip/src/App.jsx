//import { ForgotPassword } from "./pages/authenticator/ForgotPassword"
//import { Login } from './pages/authenticator/Login'
import { Register} from './pages/register/Register'




function App() {
  return (
   //<Login/>
       //<ForgotPassword/>  
      <Register/> 
  
  )
  
}

export default App
