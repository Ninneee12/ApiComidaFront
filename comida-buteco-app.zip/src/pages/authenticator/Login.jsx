import React, { useEffect, useRef, useState } from 'react'
//import { Link } from 'react-router-dom';
import Food from '../../assets/images/food.jpeg'
//Hooks
export const Login = () => {
    const PWD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%]).{8,24}$/;
    const EMAIL_REGEX = /[^@ \t\r\n]+@[^@ \t\r\n]+\.[^@ \t\r\n]+/;

    const emailRef = useRef();
    
    const [email, setEmail] = useState('');
    const [validEmail, setValidEmail] = useState(false);

    const [password, setPassword] = useState('');
    const [validPassword, setValidPassword] = useState(false);

    useEffect(() => {
        emailRef.current.focus();
    }, [])

    useEffect(() => {
        setValidEmail(EMAIL_REGEX.test(email));
    }, [email])

    useEffect(() => {
        setValidPassword(PWD_REGEX.test(password));
    }, [password])

    return (
        <div className="h-screen flex items-center justify-center"> <img src={Food} alt="food" className="h-90 w-90"/>
            <form action="" className=" w-full md:w-1/3 bg-white rounded-lg items-center" data-testid="loginForm">
                
                <h2 className=" underline decoration-red-500 hover:decoration-orange-400 text-5xl text-center text-amber-900 mb-20" data-testid="pageTitle">Login</h2>
                <div className="px-12 pb-10">
                    <div className="w-full mb-2">
                        <div className="flex justify-center">
                            <input type="email" placeholder="Email" required id="email" role="input" name="email"
                                ref={emailRef}
                                autoComplete="off"
                                onChange={(e) => setEmail(e.target.value)}
                                className="px-8 w-full border rounded py-2 text-gray-700 focus:outline-none items-center"/>                                 
                        </div>
                        <div className="w-full mb-2">
                            { validEmail || !email ? null: <div className="text-red-500 text-xs italic">Email inválido.</div> }
                        </div>
                    </div>
                    <div className="w-full mb-2">
                        <div className="flex justify-center">
                            <input type="password" placeholder="Password" required id="password" role="input"
                                autoComplete="off"
                                onChange={(e) => setPassword(e.target.value)}
                                className="px-8 w-full border rounded py-2 text-gray-700 focus:outline-none"/>
                        </div>
                        <div className="w-full mb-2">
                            { validPassword || !password ? null: <div className="text-red-500 text-xs italic">Senha inválida.</div> }
                        </div>
                    </div>
                    <button disabled={!validEmail || !validPassword}  role="button"
                        className={(validEmail && validPassword) ? "w-full mt-6 py-2 rounded bg-amber-800 text-gray-100 focus:outline-none" : "w-full mt-6 py-2 rounded bg-amber-900 text-gray-100 focus:outline-none"}>Log In</button>
                    
                    
                </div>
            </form>
        </div>
    )
}
