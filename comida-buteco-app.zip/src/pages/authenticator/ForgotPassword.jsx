import React, { useEffect, useRef, useState } from 'react'
import Food from '../../assets/images/food.jpeg'


export const ForgotPassword = () => {
    const emailRef = useRef();
    const EMAIL_REGEX = /[^@ \t\r\n]+@[^@ \t\r\n]+\.[^@ \t\r\n]+/;
    const [email, setEmail] = useState('');
    const [validEmail, setValidEmail] = useState(false);

    useEffect(() => {
        emailRef.current.focus();
    }, [])

    useEffect(() => {
        setValidEmail(EMAIL_REGEX.test(email));
    }, [email])

  return (
      
    <div className="h-screen flex items-center justify-center"><img src={Food} alt="food" className="h-90 w-90"/>
        <form className="w-full md:w-1/3 bg-white rounded-lg items-center" data-testid="loginForm">
            <h2 className=" text-5xl text-center text-amber-900 mb-10" data-testid="pageTitle">Esqueci a senha</h2>
            <h3 className="text-center mb-5">Para redefinir sua senha, informe sua conta de e-mail </h3>
            <div className="px-12 pb-10">
                <div className="w-full mb-2">
                    <div className="flex justify-center">
                        <input type="email" placeholder="Email" required id="email" role="input"
                            autoComplete="off"
                            ref={emailRef}
                            onChange={(e) => setEmail(e.target.value)}
                            className="px-8 w-full border rounded py-2 focus:border-sky-500 focus:ring-sky-500 text-gray-700 focus:outline-none"/>
                    </div>
                    <div className="w-full mb-2">
                        { validEmail || !email ? null: <div className="text-red-500 text-xs italic">Email inválido.</div> }
                    </div>
                </div>
                <button disabled={!validEmail}  role="button"
                    className={(validEmail) ? 
                        "w-full mt-6 py-2 rounded bg-amber-800 text-gray-100 focus:outline-none" : 
                        "w-full mt-6 py-2 rounded bg-amber-900 text-gray-100 focus:outline-none"}>
                            Solicitar Nova Senha
                    </button>
                                
                
            </div>
        </form>
    </div>
  )
}
