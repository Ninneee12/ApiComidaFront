import Food from '../../assets/images/food.jpeg'
import React, { useEffect, useRef, useState } from 'react'
import { text } from '@fortawesome/fontawesome-svg-core';

export const Register = () => {
    const PWD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%]).{8,24}$/;
    const EMAIL_REGEX = /[^@ \t\r\n]+@[^@ \t\r\n]+\.[^@ \t\r\n]+/;

    const emailRef = useRef();
    
    const [email, setEmail] = useState('');
    const [validEmail, setValidEmail] = useState(false);

    const [password, setPassword] = useState('');
    const [validPassword, setValidPassword] = useState(false);

    useEffect(() => {
        emailRef.current.focus();
    }, [])

    useEffect(() => {
        setValidEmail(EMAIL_REGEX.test(email));
    }, [email])

    useEffect(() => {
        setValidPassword(PWD_REGEX.test(password));
    }, [password])

return(

<div className="flex items-center justify-center min-h-screen bg-yellow-400"><img src={Food} alt="food"
        className="h-90 w-90" />
    <div className="px-5 py-6 mx-3 mt-4  bg-amber-900 shadow-lg md:w-1/4 lg:w-1/4 sm:w-1/4">
        <h3 class="text-2xl font-bold text-center"></h3>
        <form action=''>
            <div>
                <label className="text-2xl block text-yellow-400" for="Name">Nome</label>
                        <input type="text" placeholder="Nome"
                            className="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"/>
            </div>

            <div class="mt-4">
                    <label class="text-2xl block text-yellow-400" for="email">E-mail</label>
                    <input type="email" placeholder="Email" required id="email" role="input" name="email"
                                ref={emailRef}
                                autoComplete="off"
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"/>
            </div>
            <div className="w-full mb-2">
                            { validEmail || !email ? null: <div className="text-red-500 text-xs italic">Email inválido.</div> }
            </div>

            <div class="mt-4">
                    <label className="text-2xl block text-yellow-400">Senha</label>
                            <input type="password" placeholder="Senha" required id="password" role="input"
                                autoComplete="off"
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"/>
            </div>

            <div className="w-full mb-2">
                            { validPassword || !password ? null: <div className="text-red-500 text-xs italic">Senha inválida.</div> }
            </div>

            <div class="mt-4">
                    <label class="text-2xl block text-yellow-400">Confirmar a Senha</label>
                            <input type="password" placeholder="Confirme a senha"required id="password" role="input"
                                autoComplete="off"
                                onChange={(e) => setPassword(e.target.value)}
                                class="w-full px-4 py-2 mt-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600"/>
            </div>

            <div className="w-full mb-2">
                            { validPassword || !password ? null: <div className="text-red-500 text-xs italic">Senha inválida.</div> }
            </div>

            <span class="text-base text-yellow-400">A senha deve ser a mesma que o campo anterior!</span>
                <div class="flex">

                    <button disabled={!validEmail || !validPassword}  role="button" className={(validEmail && validPassword) ? "w-full px-6 py-2 mt-4 rounded-lg bg-red-600  focus:outline-none text-white": "w-full mt-6 py-2 text-white rounded bg-red-700  focus:outline-none"}>Criar uma conta </button>
                
            </div>

            <div class="mt-6 text-yellow-400 text-lg" >
                    Você já tem uma Conta? 
                    <a class="text-red-600 hover:underline mt-4 mx-3 text-lg" href="#">
                        Entrar
                    </a>
            </div>        



        </form>
    </div>
</div>
)
}